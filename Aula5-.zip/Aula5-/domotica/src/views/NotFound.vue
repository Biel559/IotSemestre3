<script setup lang="ts">

</script>

<template>
 <h1>Not Found! 😂😂😂😂😂😂😂😂</h1>
 <img src="https://s2.glbimg.com/Lz7AHbOCTWPg-uoubmWigSiBqCQ=/1200x/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2022/R/v/cYQVSDSt2ZORRKwiI3TA/carrossel-ponte-preta.jpg" alt="">
</template>

<style scoped lang="scss">

</style>