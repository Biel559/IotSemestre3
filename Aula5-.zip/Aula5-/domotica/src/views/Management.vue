<script setup lang="ts">

</script>

<template>
 <h1>Hello Management!</h1>
</template>

<style scoped lang="scss">

</style>